using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TriggerFilter : MonoBehaviour
{
    public string filterString;
}
