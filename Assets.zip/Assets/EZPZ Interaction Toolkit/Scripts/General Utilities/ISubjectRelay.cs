using UnityEngine;

public interface ISubjectRelay
{
    public void SyncSubject(GameObject subject);
    
}
