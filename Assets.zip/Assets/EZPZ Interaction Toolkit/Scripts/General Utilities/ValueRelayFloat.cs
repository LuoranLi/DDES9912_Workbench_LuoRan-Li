using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ValueRelayFloat: MonoBehaviour
{
    public float value;
}
